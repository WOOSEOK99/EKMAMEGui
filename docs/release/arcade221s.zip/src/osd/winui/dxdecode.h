// license:BSD-3-Clause
// copyright-holders:Chris Kirmse, Mike Haaland, Ren� Single, Mamesick

#ifndef DXDECODE_H
#define DXDECODE_H

const char* DirectXDecodeError(HRESULT errorval);

#endif
